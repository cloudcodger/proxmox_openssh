# Change log

# version 1.0.2

- Fixed `proxmox_ve` wait for file that had a hard coded value.

# version 1.0.1

- Fixed `proxmox_storage_dir` improper check for `shared` as bool.
- Updated `README.md`.

# version 1.0.0

- The initial release
